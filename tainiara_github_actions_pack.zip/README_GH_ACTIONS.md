# Tainiara — GitHub Actions Pack

Χρησιμοποίησε αυτό το workflow για να φτιάχνεις και να υπογράφεις το APK **Tainiara** αυτόματα στο GitHub.

## 1) Προετοιμασία Repository
- Ανέβασε ΟΛΟ το Android project (το περιεχόμενο από `TainiaraApp_Pro_with_logo.zip`) σε ένα **ιδιωτικό** GitHub repo.
- Το `app/build.gradle.kts` και το project είναι έτοιμα (JDK 17, SDK 35).

## 2) Δημιούργησε Keystore & Secrets
Φτιάξε ένα keystore τοπικά (μία φορά):
```
keytool -genkeypair -v -keystore tainiara.keystore -alias tainiara -keyalg RSA -keysize 4096 -validity 36500
```
Μετέτρεψέ το σε Base64 (Linux/macOS):
```
base64 tainiara.keystore > keystore.b64
```
**GitHub → Repo → Settings → Secrets and variables → Actions → New repository secret** και πρόσθεσε:
- `KEYSTORE_BASE64` → περιεχόμενο από `keystore.b64`
- `KEY_ALIAS` → `tainiara`
- `KEYSTORE_PASSWORD` → (ο κωδικός που έβαλες)
- `KEY_PASSWORD` → (συνήθως ίδιος με το παραπάνω)

### (Προαιρετικό) Αυτόματο ανέβασμα στο server
Αν θέλεις το GitHub να ανεβάζει το APK στον server σου (στο `/downloads/`):
- Δημιούργησε/πρόσθεσε secrets:
  - `SFTP_HOST` (π.χ. `tainiara.top`)
  - `SFTP_PORT` (π.χ. `22`)
  - `SFTP_USER`
  - `SFTP_PRIVATE_KEY` (ιδιωτικό κλειδί SSH σε PEM μορφή)
  - `SFTP_REMOTE_DIR` (π.χ. `/home/USER/public_html/downloads/`)
- Άλλαξε στο workflow το `deploy: if: false` σε `true` **ή** σβήσε τη γραμμή για να ενεργοποιηθεί η δουλειά deploy.

## 3) Τρέξε το Build
- Repo → **Actions** → **Build & Sign Tainiara APK** → **Run workflow**
- Δώσε **version** π.χ. `1.0.0` και πάτα **Run**.

Μετά το build:
- Θα βρεις το `Tainiara_v1.0.0.apk` στα **Artifacts** της εκτέλεσης.
- Θα εμφανιστεί και το **SHA‑256** στο log (βάλε το στο site σου αν θέλεις).

## 4) Βάλε το APK στον server σου
Αν δεν έχεις ενεργοποιήσει το deploy step:
- Κατέβασε το artifact `Tainiara_vX.Y.Z.apk`
- Ανέβασέ το στον server σου στο:
  `public_html/downloads/Tainiara_vX.Y.Z.apk`

Αν έχεις ενεργοποιήσει το deploy step:
- Το APK θα ανέβει αυτόματα στο `SFTP_REMOTE_DIR` (π.χ. `/public_html/downloads/`).

## 5) Τέλος
Η σελίδα λήψης είναι στο `https://tainiara.top/app/` και θα κατεβάζει από `/downloads/Tainiara_vX.Y.Z.apk`.
